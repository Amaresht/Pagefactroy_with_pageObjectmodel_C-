﻿using log4net;
using log4net.Core;
using log4net.Repository.Hierarchy;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LMSAutomation.Pages.Courses;
using LMSAutomation.Base;
using RelevantCodes.ExtentReports;

namespace LMSAutomation.Tests.CourseConsumption
{
    class Dashboard : BaseDriver
    {

    }
}
